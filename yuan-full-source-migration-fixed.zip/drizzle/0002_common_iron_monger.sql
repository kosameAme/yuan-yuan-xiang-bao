ALTER TABLE `accounts` ADD `signature` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `accounts` ADD `theme` text DEFAULT 'blue' NOT NULL;