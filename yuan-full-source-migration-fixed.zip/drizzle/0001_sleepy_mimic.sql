DROP INDEX `owner_username`;--> statement-breakpoint
CREATE UNIQUE INDEX `global_username` ON `accounts` (`username`);