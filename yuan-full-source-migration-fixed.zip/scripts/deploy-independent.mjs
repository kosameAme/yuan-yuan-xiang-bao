import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const wrangler=fileURLToPath(new URL('../node_modules/wrangler/bin/wrangler.js',import.meta.url));
for(const args of [['deploy'],['d1','migrations','apply','DB','--remote','--config','wrangler.jsonc']]){
 const r=spawnSync(process.execPath,[wrangler,...args],{stdio:'inherit'});
 if(r.error)throw r.error;
 if(r.status!==0)process.exit(r.status??1);
}
