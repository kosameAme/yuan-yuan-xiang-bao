import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "鸢鸢相抱",
  description: "按卡池记录每一次相遇，账号备份抽卡手账。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
