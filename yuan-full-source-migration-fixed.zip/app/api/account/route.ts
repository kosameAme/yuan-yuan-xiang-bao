import { validateRoleBook } from "../../journal-validation";
import { env } from 'cloudflare:workers';
export const dynamic='force-dynamic';
const encoder=new TextEncoder();
const hex=(v:ArrayBuffer)=>Array.from(new Uint8Array(v),b=>b.toString(16).padStart(2,'0')).join('');
async function hash(s:string){return hex(await crypto.subtle.digest('SHA-256',encoder.encode(s)))}
async function passwordHash(p:string,salt:string){const key=await crypto.subtle.importKey('raw',encoder.encode(p),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:encoder.encode(salt),iterations:100000,hash:'SHA-256'},key,256))}
function same(a:string,b:string){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0}
const json=(data:unknown,status=200,cookie?:string)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
function validate(s:unknown){validateRoleBook(s)}
async function handle(req:Request){
 const db=env.DB;if(!db)return json({error:'账号服务暂未配置'},503);
 const owner='password-account';
 if(req.method==='POST'&&req.headers.get('Origin')!==new URL(req.url).origin)return json({error:'请求来源无效'},403);
 const action=new URL(req.url).searchParams.get('action')||'me';let body:any={};
 if(req.method==='POST'){if(!req.headers.get('content-type')?.includes('application/json'))return json({error:'请求格式无效'},415);const raw=await req.text();if(encoder.encode(raw).length>1000000)return json({error:'云端备份最大1MB，请使用下载备份'},413);try{body=JSON.parse(raw)}catch{return json({error:'请求数据无效'},400)}}
 const now=Date.now();const cookie=(token:string,age=604800)=>`__Host-yuan-session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;
 const rawToken=req.headers.get('cookie')?.match(/(?:^|;\s*)__Host-yuan-session=([a-f0-9]{64})(?:;|$)/)?.[1];let user:any=null;
 if(rawToken)user=await db.prepare('SELECT a.id,a.username,a.signature,a.theme FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires>?').bind(await hash(rawToken),now).first();
 if(req.method==='GET'){
  if(action==='me')return json({user});
  if(!user)return json({error:'请先登录账号'},401);
  if(action==='backups'){const rows=await db.prepare('SELECT id,created_at FROM backups WHERE account_id=? ORDER BY created_at DESC LIMIT 10').bind(user.id).all();return json({backups:rows.results})}
  if(action==='backup'){const row:any=await db.prepare('SELECT payload FROM backups WHERE id=? AND account_id=?').bind(new URL(req.url).searchParams.get('id'),user.id).first();return row?json({data:JSON.parse(row.payload)}):json({error:'备份不存在'},404)}
  return json({error:'操作不存在'},404)
 }
 if(action==='login'||action==='register'){
  if(typeof body.username!=='string'||!/^[A-Za-z0-9_]{3,32}$/.test(body.username)||typeof body.password!=='string'||body.password.length<8||body.password.length>128)return json({error:'账号须为3–32位字母、数字或下划线；密码须为8–128位'},400);
  const username=body.username.toLowerCase(),throttle=await hash('username:'+username),ipThrottle=await hash('ip:'+(req.headers.get('cf-connecting-ip')||'local')),window=Math.floor(now/900000);
  const ipAttempt:any=await db.prepare('INSERT INTO attempts (key,count,window) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END,window=excluded.window RETURNING count').bind(ipThrottle,window).first();
  if(ipAttempt.count>60)return json({error:'请求过于频繁，请稍后再试'},429);
  const attempt:any=await db.prepare('INSERT INTO attempts (key,count,window) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN window=excluded.window THEN count+1 ELSE 1 END,window=excluded.window RETURNING count').bind(throttle,window).first();
  if(attempt.count>20)return json({error:'尝试次数过多，请15分钟后再试'},429);
  let account:any=await db.prepare('SELECT * FROM accounts WHERE username=?').bind(username).first();
  if(action==='register'){
   if(account)return json({error:'账号已被使用，请换一个'},409);
   const salt=crypto.randomUUID(),id=crypto.randomUUID(),ph=await passwordHash(body.password,salt);
   try{await db.prepare('INSERT INTO accounts (id,owner,username,salt,password_hash,created_at,theme) VALUES (?,?,?,?,?,?,?)').bind(id,owner,username,salt,ph,now,'mono').run()}catch{return json({error:'账号创建失败，请稍后重试'},409)}
   account={id,username};
  }else{
   const ph=await passwordHash(body.password,account?.salt||'unknown-user-dummy-salt');
   if(!account||!same(ph,account.password_hash))return json({error:'账号或密码不正确'},401);
  }
  const token=hex(crypto.getRandomValues(new Uint8Array(32)).buffer);await db.batch([db.prepare('DELETE FROM sessions WHERE expires<?').bind(now),db.prepare('INSERT INTO sessions (token_hash,account_id,owner,expires) VALUES (?,?,?,?)').bind(await hash(token),account.id,owner,now+604800000)]);
  return json({user:{id:account.id,username:account.username,signature:account.signature||'',theme:account.theme||'mono'}},200,cookie(token));
 }
 if(action==='logout'){if(rawToken)await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hash(rawToken)).run();return json({ok:true},200,cookie('',0))}
 if(!user)return json({error:'请先登录账号'},401);
 if(action==='profile'){
  if(typeof body.signature!=='string'||body.signature.length>200||!['mono','retro','glassblue','purple','blue'].includes(body.theme))return json({error:'签名须在200字以内，主题须为支持的颜色'},400);
  await db.prepare('UPDATE accounts SET signature=?,theme=? WHERE id=?').bind(body.signature.trim(),body.theme,user.id).run();
  return json({user:{...user,signature:body.signature.trim(),theme:body.theme}});
 }
 if(action==='backup'){
  try{validate(body.data)}catch(e:any){return json({error:e.message},400)}
  const id=crypto.randomUUID();await db.batch([db.prepare('INSERT INTO backups (id,account_id,payload,created_at) VALUES (?,?,?,?)').bind(id,user.id,JSON.stringify(body.data),now),db.prepare('DELETE FROM backups WHERE account_id=? AND id NOT IN (SELECT id FROM backups WHERE account_id=? ORDER BY created_at DESC LIMIT 10)').bind(user.id,user.id)]);return json({id,created_at:now});
 }
 return json({error:'操作不存在'},404)
}
export async function GET(req:Request){try{return await handle(req)}catch{return json({error:'服务暂时不可用，请稍后重试'},503)}}
export async function POST(req:Request){try{return await handle(req)}catch{return json({error:'服务暂时不可用，请稍后重试'},503)}}
