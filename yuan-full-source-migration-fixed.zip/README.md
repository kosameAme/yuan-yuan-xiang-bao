# 鸢鸢相抱 · 完整源码迁移修复版

基于原仓库 yuan-yuan-xiang-bao-source.zip 修复。保留原始网页、独立账号、角色统计、云端备份与数据库迁移，移除活动构建配置中的 Sites 依赖。没有跳转到 chatgpt.site 的入口。

## 部署
把本包解压后的实际文件放入 GitHub 的 app-source/ 目录。
Cloudflare Workers 连接仓库，根目录 app-source，Node >=22.13，安装 pnpm install --frozen-lockfile，构建 pnpm run build，部署 pnpm run deploy。
DB 绑定在 wrangler.jsonc 中声明；新账号下 Wrangler 会申请名为 yuan-journal 的 D1。部署脚本先部署应用，再执行三份远程迁移。迁移完成前请勿开始注册账号。
如已有 D1，在 wrangler.jsonc 的 d1_databases 中增加真实 database_id 后再发布。数据库应为该应用的独立数据库，不能绑定其他应用的库。

## 验证
2026-10-13 已执行生产构建、Wrangler dry-run、注册/登录/密码校验/安全会话/签名主题/重复用户名/备份隔离/十份保留/备份恢复/Origin校验检查。尚未获得 GitHub 写入和 Cloudflare 可操作会话，尚未在线部署与真机验收。

## 旧数据
新数据库没有旧账号或云端备份。旧站需导出 JSON，新站重新注册并导入。旧站与旧数据库均未修改。
