# 鸢签 · 代号鸢抽卡手账

一个无依赖、适配手机的静态网站。按不同卡池独立保存抽卡记录，不需要安装 Node.js。

## 功能
- 新建/修改/删除卡池，区分限定、常驻、活动和其他卡池。
- 单抽、十连、自定义抽数；支持一次多次出金的位置记录。
- 统计累计抽数、出金次数、出金率、距上次出金、平均出金间隔。
- 自定义保底参考；不自动处理保底继承、大小保底、UP或卡池游戏规则。
- 日期、角色和备注；删除记录自动重算；JSON 导出和导入。

## 上传 GitHub Pages
1. 在 GitHub 创建一个仓库，例如 `yuan-journal`。免费账户可以使用公开仓库。
2. 将压缩包解压，上传 `index.html`、`style.css`、`app.js` 和此说明到仓库根目录，不要再套一层文件夹。
3. 仓库 Settings → Pages → Build and deployment，Source 选 `Deploy from a branch`。
4. Branch 选 `main`，目录选 `/(root)`，点击 Save。
5. 部署完成后，从 Pages 设置页打开网站地址，通常是 `https://你的用户名.github.io/yuan-journal/`。

官方说明：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## 数据和计算说明
记录保存在当前网站域名的浏览器 localStorage 内，不上传到 GitHub，不会自动跨设备同步。更换浏览器、网站域名、清除网站数据或使用隐私浏览都可能导致记录不再可见。定期导出 JSON 文件；转移到 GitHub Pages 后，在新地址导入即可。导入覆盖现有数据，界面会提示确认。

记录按添加顺序确定抽卡序号，日期只用作标记。补录请按真实抽卡顺序添加。本次出金位置为本次的第几抽，例如十连第3和9抽出金填 `3,9`。平均出金按从第1抽到首次出金以及之后每个已完成出金区间计算，未出金的末尾区间不计入平均。如果从中途开始记录，该平均值仅对应已录入部分。

这是非官方手动记录工具，无自动抓取、登录账号或游戏接口。没有包含游戏美术素材。
