(()=>{
  const tabs=[document.getElementById('recruitmentTab'),document.getElementById('collectionTab')];
  const panels=[document.getElementById('recruitmentPanel'),document.getElementById('collectionPanel')];
  let active=0;
  function select(index,focus=false){
    active=index;
    tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;panels[i].hidden=i!==index;});
    document.getElementById('journalHeading').textContent=index?'我的卡池':'招募记录';
    document.getElementById('journalCaption').textContent=index?'收藏每个卡池里的幸运。':'每一次相遇，都有迹可循。';
    if(focus)tabs[index].focus();
  }
  tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>select(i));tab.addEventListener('keydown',event=>{
    if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();select(event.key==='Home'?0:event.key==='End'?1:1-active,true);}
  });});
  document.getElementById('backPools').addEventListener('click',()=>select(1));
  const originalOpen=window.openDetail;
  if(originalOpen)window.openDetail=function(id){document.getElementById('collectionPanel').hidden=true;return originalOpen(id);};
  // Both panels live inside overview, so detail views and role changes retain existing navigation.
  select(0);
})();
