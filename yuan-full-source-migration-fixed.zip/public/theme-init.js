'use strict';
const THEME_COLORS=['mono','retro','glassblue','purple','blue'];
function applyTheme(theme){theme=({pink:'mono',green:'retro',gray:'retro',yellow:'glassblue'})[theme]||theme;if(!THEME_COLORS.includes(theme))theme='mono';document.documentElement.dataset.theme=theme;try{localStorage.setItem('yuan-display-theme',theme)}catch{}return theme}
try{applyTheme(localStorage.getItem('yuan-display-theme')||'mono')}catch{applyTheme('mono')}
